<?php
/*
Plugin Name: BuzzMag Theme Addons
Plugin URI: https://flatlayers.com
Description: BuzzMag theme addons (Post Formats, Widgets, Author Social Profiles).
Version: 1.0
Author: FlatLayers
Author URI: https://flatlayers.com
*/


if (!defined('FL_BUZZMAG_ADDONS_VERSION')) {

	define('FL_BUZZMAG_ADDONS_VERSION', '1.0');

	function fl_buzzmag_addons_base_url() {
		return trailingslashit(apply_filters('fl_buzzmag_addons_base_url', plugins_url('', __FILE__)));
	}

	function fl_buzzmag_addons_init() {
	    load_plugin_textdomain( 'flatlayers', false, fl_buzzmag_addons_base_url() . '/languages' ); 
	}
	add_action( 'plugins_loaded', 'fl_buzzmag_addons_init' );

	// Post Formats
	include_once( 'addons/post-formats.php' );

	// User Socials
	include_once( 'addons/user-socials.php' );

	// Widgets
	include_once( 'addons/widgets/latest-posts.php');
	include_once( 'addons/widgets/category-posts.php' );
	include_once( 'addons/widgets/ids-posts.php' );
	include_once( 'addons/widgets/random-posts.php' );
	include_once( 'addons/widgets/trending-posts.php' );
	include_once( 'addons/widgets/about.php');
	include_once( 'addons/widgets/socials.php');


} // end defined check
