<?php
/*
 * FLatLayers Social Profiles Widget
 */

class Fl_Socials extends WP_Widget {

    public function __construct() {        
        $widget_ops = array( 'classname' => 'fl-socials', 'description' => 'Social media profiles Widget' );
        parent::__construct(
            'Fl_Socials',  // Base ID
            fl_theme_name.' Social Profiles', // Name
            $widget_ops
        );
    }

    /**
     * Front-end display of widget.
     */
    public function widget($args, $instance) {
        extract($args);
        $title = apply_filters('widget_title', $instance['title']);
        $behance = $instance['behance'];
        $delicious = $instance['delicious'];
        $deviantart = $instance['deviantart'];
        $digg = $instance['digg'];
        $dribbble = $instance['dribbble'];
        $facebook = $instance['facebook'];
        $flickr = $instance['flickr'];
        $google = $instance['google'];
        $instagram = $instance['instagram'];
        $linkedin = $instance['linkedin'];
        $mail = $instance['mail'];
        $pinterest = $instance['pinterest'];
        $rss = $instance['rss'];
        $soundcloud = $instance['soundcloud'];
        $tumblr = $instance['tumblr'];        
        $twitter = $instance['twitter'];
        $vk = $instance['vk'];
        $vimeo = $instance['vimeo'];
        $vine = $instance['vine'];
        $youtube = $instance['youtube'];
        
        // social profile link
        $behance_profile = '<a href="' . esc_url( $behance ) . '"><i class="fa fa-behance"></i><span>'. esc_html('Behance') .'</span></a>';
        $delicious_profile = '<a href="' . esc_url( $delicious ) . '"><i class="fa fa-delicious"></i><span>'. esc_html('Delicious') .'</span></a>';
        $deviantart_profile = '<a href="' . esc_url( $deviantart ) . '"><i class="fa fa-deviantart"></i><span>'. esc_html('Deviantart') .'</span></a>';
        $digg_profile = '<a href="' . esc_url( $digg ) . '"><i class="fa fa-digg"></i><span>'. esc_html('Digg') .'</span></a>';
        $dribbble_profile = '<a href="' . esc_url( $dribbble ) . '"><i class="fa fa-dribbble"></i><span>'. esc_html('Dribbble') .'</span></a>';
        $facebook_profile = '<a href="' . esc_url( $facebook ) . '"><i class="fa fa-facebook"></i><span>'. esc_html('Facebook') .'</span></a>';
        $flickr_profile = '<a href="' . esc_url( $flickr ) . '"><i class="fa fa-flickr"></i><span>'. esc_html('Flickr') .'</span></a>';
        $google_profile = '<a href="' . esc_url( $google ) . '"><i class="fa fa-google"></i><span>'. esc_html('Google') .'</span></a>';
        $instagram_profile = '<a href="' . esc_url( $instagram ) . '"><i class="fa fa-instagram"></i><span>'. esc_html('Instagram') .'</span></a>';
        $linkedin_profile = '<a href="' . esc_url( $linkedin ) . '"><i class="fa fa-linkedin"></i><span>'. esc_html('Linkedin') .'</span></a>';
        $mail_profile = '<a href="' . esc_url( $mail ) . '"><i class="fa fa-envelope"></i><span>'. esc_html('E-mail') .'</span></a>';
        $pinterest_profile = '<a href="' . esc_url( $pinterest ) . '"><i class="fa fa-pinterest-p"></i><span>'. esc_html('Pinterest') .'</span></a>';
        $rss_profile = '<a href="' . esc_url( $rss ) . '"><i class="fa fa-rss"></i><span>'. esc_html('RSS') .'</span></a>';
        $soundcloud_profile = '<a href="' . esc_url( $soundcloud ) . '"><i class="fa fa-soundcloud"></i><span>'. esc_html('Soundcloud') .'</span></a>';
        $tumblr_profile = '<a href="' . esc_url( $tumblr ) . '"><i class="fa fa-tumblr"></i><span>'. esc_html('Tumblr') .'</span></a>';
        $twitter_profile = '<a href="' . esc_url( $twitter ) . '"><i class="fa fa-twitter"></i><span>'. esc_html('Twitter') .'</span></a>';
        $vk_profile = '<a href="' . esc_url( $vk ) . '"><i class="fa fa-vk"></i><span>'. esc_html('VK') .'</span></a>';
        $vimeo_profile = '<a href="' . esc_url( $vimeo ) . '"><i class="fa fa-vimeo"></i><span>'. esc_html('Vimeo') .'</span></a>';
        $vine_profile = '<a href="' . esc_url( $vine ) . '"><i class="fa fa-vine"></i><span>'. esc_html('Vine') .'</span></a>';
        $youtube_profile = '<a href="' . esc_url( $youtube ) . '"><i class="fa fa-youtube-play"></i><span>'. esc_html('Youtube') .'</span></a>';
        echo ( $args['before_widget'] );

        if (!empty($title)) {
            echo ( $args['before_title'] . $title . $args['after_title'] );
        }

        echo '<div class="social-icons">';
        echo (!empty($behance) ) ? $behance_profile : null;
        echo (!empty($delicious) ) ? $delicious_profile : null;
        echo (!empty($deviantart) ) ? $deviantart_profile : null;
        echo (!empty($digg) ) ? $digg_profile : null;
        echo (!empty($dribbble) ) ? $dribbble_profile : null;
        echo (!empty($facebook) ) ? $facebook_profile : null;
        echo (!empty($flickr) ) ? $flickr_profile : null;
        echo (!empty($google) ) ? $google_profile : null;
        echo (!empty($instagram) ) ? $instagram_profile : null;
        echo (!empty($linkedin) ) ? $linkedin_profile : null;
        echo (!empty($mail) ) ? $mail_profile : null;
        echo (!empty($pinterest) ) ? $pinterest_profile : null;
        echo (!empty($rss) ) ? $rss_profile : null;
        echo (!empty($soundcloud) ) ? $soundcloud_profile : null;
        echo (!empty($tumblr) ) ? $tumblr_profile : null;
        echo (!empty($twitter) ) ? $twitter_profile : null;
        echo (!empty($vk) ) ? $vk_profile : null;
        echo (!empty($vimeo) ) ? $vimeo_profile : null;
        echo (!empty($vine) ) ? $vine_profile : null;
        echo (!empty($youtube) ) ? $youtube_profile : null;
        echo '</div>';

        echo ( $args['after_widget'] );
    }

    /**
     * Back-end widget form.
     */
    public function form($instance) {
        $instance = wp_parse_args( (array) $instance, array( 
            'title' => '',
            'behance' => '',
            'delicious' => '',
            'deviantart'  => '',
            'digg'  => '',
            'dribbble' => '',
            'facebook'  => '',
            'flickr' => '',
            'google'  => '',
            'instagram' => '',
            'linkedin'  => '',
            'mail'  => '',
            'pinterest'  => '',
            'rss'  => '',
            'soundcloud' => '',
            'tumblr'  => '',
            'twitter'  => '',
            'vk' => '',
            'vimeo' => '',
            'vine' => '',
            'youtube'  => '',
            ) );
        ?>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id('title') ); ?>"><?php echo 'Title:'; ?></label><br>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id('title') ); ?>" name="<?php echo esc_attr( $this->get_field_name('title') ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id('behance') ); ?>"><?php echo 'Behance:'; ?></label><br>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id('behance') ); ?>" name="<?php echo esc_attr( $this->get_field_name('behance') ); ?>" type="text" value="<?php echo esc_url( $instance['behance'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id('delicious') ); ?>"><?php echo 'Delicious:'; ?></label><br>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id('delicious') ); ?>" name="<?php echo esc_attr( $this->get_field_name('delicious') ); ?>" type="text" value="<?php echo esc_url( $instance['delicious'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id('deviantart') ); ?>"><?php echo 'Deviantart:'; ?></label><br>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id('deviantart') ); ?>" name="<?php echo esc_attr( $this->get_field_name('deviantart') ); ?>" type="text" value="<?php echo esc_url( $instance['deviantart'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id('digg') ); ?>"><?php echo 'Digg:'; ?></label><br>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id('digg') ); ?>" name="<?php echo esc_attr( $this->get_field_name('digg') ); ?>" type="text" value="<?php echo esc_url( $instance['digg'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id('dribbble') ); ?>"><?php echo 'Dribbble:'; ?></label><br>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id('dribbble') ); ?>" name="<?php echo esc_attr( $this->get_field_name('dribbble') ); ?>" type="text" value="<?php echo esc_url( $instance['dribbble'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id('facebook') ); ?>"><?php echo 'Facebook:'; ?></label><br>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id('facebook') ); ?>" name="<?php echo esc_attr( $this->get_field_name('facebook') ); ?>" type="text" value="<?php echo esc_url( $instance['facebook'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id('flickr') ); ?>"><?php echo 'Flickr:'; ?></label><br>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id('flickr') ); ?>" name="<?php echo esc_attr( $this->get_field_name('flickr') ); ?>" type="text" value="<?php echo esc_url( $instance['flickr'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id('google') ); ?>"><?php echo 'Google:'; ?></label><br>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id('google') ); ?>" name="<?php echo esc_attr( $this->get_field_name('google') ); ?>" type="text" value="<?php echo esc_url( $instance['google'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id('instagram') ); ?>"><?php echo 'Instagram:'; ?></label><br>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id('instagram') ); ?>" name="<?php echo esc_attr( $this->get_field_name('instagram') ); ?>" type="text" value="<?php echo esc_url( $instance['instagram'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id('linkedin') ); ?>"><?php echo 'Linkedin:'; ?></label><br>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id('linkedin') ); ?>" name="<?php echo esc_attr( $this->get_field_name('linkedin') ); ?>" type="text" value="<?php echo esc_url( $instance['linkedin'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id('mail') ); ?>"><?php echo 'Email:'; ?></label><br>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id('mail') ); ?>" name="<?php echo esc_attr( $this->get_field_name('mail') ); ?>" type="text" value="<?php echo esc_url( $instance['mail'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id('pinterest') ); ?>"><?php echo 'Pinterest:'; ?></label><br>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id('pinterest') ); ?>" name="<?php echo esc_attr( $this->get_field_name('pinterest') ); ?>" type="text" value="<?php echo esc_url( $instance['pinterest'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id('rss') ); ?>"><?php echo 'RSS:'; ?></label><br>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id('rss') ); ?>" name="<?php echo esc_attr( $this->get_field_name('rss') ); ?>" type="text" value="<?php echo esc_url( $instance['rss'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id('soundcloud') ); ?>"><?php echo 'Soundcloud:'; ?></label><br>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id('soundcloud') ); ?>" name="<?php echo esc_attr( $this->get_field_name('soundcloud') ); ?>" type="text" value="<?php echo esc_url( $instance['soundcloud'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id('tumblr') ); ?>"><?php echo 'Tumblr:'; ?></label><br>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id('tumblr') ); ?>" name="<?php echo esc_attr( $this->get_field_name('tumblr') ); ?>" type="text" value="<?php echo esc_url( $instance['tumblr'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id('twitter') ); ?>"><?php echo 'Twitter:'; ?></label><br>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id('twitter') ); ?>" name="<?php echo esc_attr( $this->get_field_name('twitter') ); ?>" type="text" value="<?php echo esc_url( $instance['twitter'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id('vk') ); ?>"><?php echo 'VK:'; ?></label><br>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id('vk') ); ?>" name="<?php echo esc_attr( $this->get_field_name('vk') ); ?>" type="text" value="<?php echo esc_url( $instance['vk'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id('vimeo') ); ?>"><?php echo 'Vimeo:'; ?></label><br>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id('vimeo') ); ?>" name="<?php echo esc_attr( $this->get_field_name('vimeo') ); ?>" type="text" value="<?php echo esc_url( $instance['vimeo'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id('vine') ); ?>"><?php echo 'Vine:'; ?></label><br>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id('vine') ); ?>" name="<?php echo esc_attr( $this->get_field_name('vine') ); ?>" type="text" value="<?php echo esc_url( $instance['vine'] ); ?>">
        </p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id('youtube') ); ?>"><?php echo 'Youtube:'; ?></label><br>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id('youtube') ); ?>" name="<?php echo esc_attr( $this->get_field_name('youtube') ); ?>" type="text" value="<?php echo esc_url( $instance['youtube'] ); ?>">
        </p>

        <?php
    }

    /**
     * Sanitize widget form values as they are saved.
     */
    public function update($new_instance, $old_instance) {
        $instance = $old_instance;

        $instance['title']      = strip_tags( $new_instance['title'] );
        $instance['behance']    = $new_instance['behance'];
        $instance['delicious']  = $new_instance['delicious'];
        $instance['deviantart'] = $new_instance['deviantart'];
        $instance['digg']       = $new_instance['digg'];
        $instance['dribbble']   = $new_instance['dribbble'];
        $instance['facebook']   = $new_instance['facebook'];
        $instance['flickr']     = $new_instance['flickr'];
        $instance['google']     = $new_instance['google'];
        $instance['instagram']  = $new_instance['instagram'];
        $instance['linkedin']   = $new_instance['linkedin'];
        $instance['rss']        = $new_instance['rss'];
        $instance['soundcloud'] = $new_instance['soundcloud'];
        $instance['tumblr']     = $new_instance['tumblr'];
        $instance['twitter']    = $new_instance['twitter'];
        $instance['vimeo']      = $new_instance['vimeo'];
        $instance['youtube']    = $new_instance['youtube'];
        $instance['pinterest']    = $new_instance['pinterest'];
        $instance['vine']    = $new_instance['vine'];
        $instance['vk']    = $new_instance['vk'];
        $instance['mail']    = $new_instance['mail'];

        return $instance;
    }

}

// register widget
function register_fl_socials() {
    register_widget('Fl_Socials');
}

add_action('widgets_init', 'register_fl_socials');

