<?php
/*
 * FLatLayers Trending Posts Widget
 */

class FL_Trending_Posts extends WP_Widget {
	
	public function __construct() {        
        $widget_ops = array( 'classname' => 'fl-posts-widget', 'description' => 'Trending Posts Widget' );
        parent::__construct(
            'FL_Trending_Posts',  // Base ID
            fl_theme_name.' Trending Posts', // Name
            $widget_ops
        );
		
	}
	
	/**
	 * Front-end display of widget
	**/
	public function widget( $args, $instance ) {
		extract($args);
		$title = apply_filters('widget_title', $instance['title']);
		$posts_num = isset( $instance['posts_num'] ) ? $instance['posts_num'] : '5';
		$posts_date = isset( $instance['posts_date'] ) ? $instance['posts_date'] : '7';
		$hide_img = isset( $instance['hide_img'] ) ? true : false;

		global $post;
		$date = $posts_date . ' days ago';
		$loop = new WP_Query(
			array(
	            'meta_key'            => 'post_views_count',
	            'orderby'             => 'meta_value_num',
	            'post_type'           => 'post',
	            'ignore_sticky_posts' => 1,            
				'posts_per_page'      => $posts_num,
	            'order'               => 'DESC',
	            'date_query'          => array(
	                array(
	                    'after' => $date
	                )
	            )
	        )
		);
		
        if ( $loop->have_posts() ) {

			echo ( $args['before_widget'] );

            if (!empty($title) ) {
	            echo ( $args['before_title'] . $title . $args['after_title'] );
	        }

			while ( $loop->have_posts() ) {
            	$loop->the_post();
				?>
				<article class="fl-post <?php if ( $hide_img === true ) { echo 'count'; } else { echo 'trend'; } ?>">
                    <div class="fl-picture">
                    	<a href="<?php the_permalink(); ?>">
                		<?php
	                    	if ( $hide_img === false ) {
	                    		if ( has_post_thumbnail() ) {	                    			
		                    		the_post_thumbnail('buzzmag_medium');
	                    		} else {
									echo '<img src="'. fl_theme_path . '/img/buzzmag_medium.png">';
	                    		}

	                    		if ( has_post_format( 'audio' ) ) {
					                echo '<div class="format-overlay"><i class="fa fa-music"></i></div>';
					            } elseif ( has_post_format( 'video' ) ) {
					                echo '<div class="format-overlay"><i class="fa fa-play"></i></div>';
					            } elseif ( has_post_format( 'gallery' ) ) {
					                echo '<div class="format-overlay"><i class="fa fa-camera"></i></div>';
					            }
	                    	}
	                    	echo esc_html( get_the_title() );
                    	?>
                        </a>
                    </div>
		        	<div class="content">
		                <h4 class="title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>

		                <span class="fl-meta category"><?php echo the_category(' / '); ?></span>

		                <?php if ( !get_theme_mod( 'hide_meta_date' ) ) { ?>
			                <span class="fl-meta"><i class="fa fa-clock-o"></i><?php echo human_time_diff( get_the_time('U'), current_time('timestamp') ) . esc_html__( ' ago', 'buzzmag' ); ?></span>
			            <?php }

		                if ( !get_theme_mod( 'hide_meta_views' ) ) { ?>
			                <span class="fl-meta"><i class="fa fa-eye"></i><?php echo buzzmag_getpostviews(get_the_ID()); ?></span>
			            <?php } ?>
	                </div>
	           	</article>

            <?php }

            echo ( $args['after_widget'] );

			wp_reset_postdata();    
		}
		
	}	
	
	/**
     * Back-end widget form.
     */
    public function form( $instance ) {
        $instance = wp_parse_args( (array) $instance, array( 
			'title'      => '',
			'posts_num'  => '5',
			'posts_date'  => '7',
			'hide_img' => 'off'
		) );
	?>
	<p>
        <label for="<?php echo esc_attr( $this->get_field_id('title') ); ?>"><?php echo esc_html_e( 'Title:', 'flatlayers' ); ?></label><br>
        <input class="widefat" id="<?php echo esc_attr( $this->get_field_id('title') ); ?>" name="<?php echo esc_attr( $this->get_field_name('title') ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ); ?>">
    </p>
	<p>
        <label for="<?php echo esc_attr( $this->get_field_id('posts_num') ); ?>"><?php echo esc_html_e( 'Number of Posts:', 'flatlayers'); ?></label><br>
        <input class="widefat" id="<?php echo esc_attr( $this->get_field_id('posts_num') ); ?>" name="<?php echo esc_attr( $this->get_field_name('posts_num') ); ?>" type="number" value="<?php echo esc_attr( $instance['posts_num'] ); ?>">
    </p>
    <p>
        <label for="<?php echo esc_attr( $this->get_field_id('posts_date') ); ?>"><?php echo esc_html_e( 'Display treding posts for last number of days:', 'flatlayers'); ?></label><br>
        <input class="widefat" id="<?php echo esc_attr( $this->get_field_id('posts_date') ); ?>" name="<?php echo esc_attr( $this->get_field_name('posts_date') ); ?>" type="number" value="<?php echo esc_attr( $instance['posts_date'] ); ?>">
    </p>
    <p>
        <input id="<?php echo esc_attr( $this->get_field_id('hide_img') ); ?>" name="<?php echo esc_attr( $this->get_field_name('hide_img') ); ?>" type="checkbox" <?php checked( $instance['hide_img'], 'on' ); ?>> 
        <label for="<?php echo esc_attr( $this->get_field_id('hide_img') ); ?>"><?php echo esc_html_e( 'Hide Post thumbnail', 'flatlayers' ); ?></label>
    </p>
	<?php
	}

	/**
     * Sanitize widget form values as they are saved.
     */
    public function update( $new_instance, $old_instance ) {
        $instance = $old_instance;
        
        $instance['title'] = strip_tags( $new_instance['title'] );
        $instance['posts_num']  = $new_instance['posts_num'];
	    $instance['posts_date']  = $new_instance['posts_date'];
		$instance['hide_img']  = $new_instance['hide_img'];

        return $instance;
    }
    
}

// register widget
function register_fl_trending_posts() {
	register_widget( 'FL_Trending_Posts' );
}

add_action('widgets_init', 'register_fl_trending_posts');